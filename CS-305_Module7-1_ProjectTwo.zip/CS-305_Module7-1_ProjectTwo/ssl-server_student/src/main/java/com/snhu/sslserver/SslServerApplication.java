/*
 * Name:  Sumiko Mitchell 
 * Class: CS-305
 * Date:  2/22/2025
 * Description: Generates a SHA-256 checksum for a predefined string.
 */

package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// SM: Added for project
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;            
import java.security.NoSuchAlgorithmException; 

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	
}

@RestController
class SslServerController {
	
	// SM: Helper method to covert byte array to hex string
	// Source: Tian, B., & Tian, B. (2024, September 7). SHA-256 hashing in Java | Baeldung. Baeldung. https://www.baeldung.com/sha-256-hashing-java
	    private static String convertBytesToHex(byte[] hash) {

	    	StringBuilder hexString = new StringBuilder (2 * hash.length);
	    	
	    	for (int i = 0; i < hash.length; i++) {
	    		String hex = Integer.toHexString(0xff & hash[i]);
	    		if(hex.length() == 1) {
	    			hexString.append('0');
	    		}
	    		hexString.append(hex);
	    	}
	    	
	    	return hexString.toString();
	    }	
	
	// DONE 2/22/2025 SM. FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
	    @RequestMapping("/hash")
	    public String generateChecksum() {
	        try {
	        	
	            // SM: Static data
	            String data = "Sumiko Mitchell";
	            
	            // SM: Validate input
	            if (data == null || data.isEmpty()) {
	            	throw new IllegalArgumentException("Data cannot be empty.");
	            }
	            
	            // SM: Create instance of MessageDigest
	            MessageDigest digest = MessageDigest.getInstance("SHA-256");

	            // SM: Convert data into raw bytes
	            digest.update(data.getBytes(StandardCharsets.UTF_8));
	            
	            // SM: Declare hash variable to hold array of bytes
	            byte[] hash = digest.digest();

	            // SM: Generate hash
	            String checkSum = convertBytesToHex(hash);
	            
	            // Return HTML response with my name, the algorithm used, and checksum value
	            return "<html><body>" +
	                    "<p><strong>Data:</strong> " + data + "</p>" +
	                    "<p><strong>Algorithm:</strong> SHA-256</p>" +
	                    "<p><strong>Checksum Value:</strong> " + checkSum + "</p>" +
	                    "</body></html>";

	        } catch (NoSuchAlgorithmException e) {
	            return "Error generating hash: " + e.getMessage();
	        }
	    }
}



